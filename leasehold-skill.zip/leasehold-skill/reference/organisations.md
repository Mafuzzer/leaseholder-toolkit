# Useful organisations

## Free advisory bodies

**The Leasehold Advisory Service (LEASE)**
Government-funded free advice service for leaseholders. The advice is free, but there is no helpline to ring. You either book a 15-minute phone appointment or send a written enquiry, both through the enquiry form on their website. There are word limits on each, and a cap on how many enquiries you can make. They give initial advice on your rights; they don't advise on tribunal or litigation strategy.
- Website: lease-advice.org — start with the enquiry form
- They publish one number, 020 7832 2500. It is an administrative line, not an advice line — use it for anything to do with your appointment. Nobody will give you advice on it

**Leasehold Knowledge Partnership (LKP)**
Charity covering leasehold abuses, sector news, and reform efforts. Useful for context and awareness, not for individual casework.
- Website: leaseholdknowledge.com

**Citizens Advice**
Free, confidential advice on housing and consumer matters.
- Website: citizensadvice.org.uk

**Shelter**
Housing-focused charity, useful for broader housing-related issues.
- Website: shelter.org.uk

## Redress schemes

**The Property Ombudsman (TPO)**
Approved redress scheme for managing agents. Can look at how an agent behaved; cannot rule on whether a service charge is reasonable — that's the tribunal's job.

Expect a modest sum rather than a windfall. TPO says its average awards are "between £100 and £400", and that awards "tend to be hundreds rather than thousands of pounds". Don't promise anyone a maximum figure: the current rules set the ceiling in each agent's own membership agreement rather than publishing a number. Money the agent charged you when it shouldn't have is treated separately from compensation, and isn't capped in the same way.

**Two deadlines, and they're easy to miss.** The complaint has to reach TPO within twelve months of the agent's final viewpoint letter. And TPO won't look at anything that happened more than twelve months before you first complained to the agent in writing.
- Website: tpos.co.uk

**Property Redress** (formerly the Property Redress Scheme)
The other government-approved redress scheme for managing agents. Same eight-week trigger as TPO. Which one applies depends on which scheme your agent belongs to — check their website or ask them.
- Website: propertyredress.co.uk

## Statutory and court bodies

**First-tier Tribunal (Property Chamber)**
The statutory tribunal for service charge and leasehold disputes in England.
- Website: gov.uk/courts-tribunals/first-tier-tribunal-property-chamber
- Application fee: £114
- Hearing fee: £227

**Money Claims** (Online Civil Money Claims)
The online service for issuing a County Court money claim, including a post-tribunal refund claim. This is the one gov.uk sends individuals to.
- Website: moneyclaims.service.gov.uk
- Watch out: there is an older, separate service called Money Claim Online (MCOL) at moneyclaim.gov.uk. Different site, different form. Check you're on the right one before you start filling anything in.

**HM Courts and Tribunals Service — fee remission**
Form EX160 for help with court and tribunal fees if on a low income or receiving certain benefits.
- Search: gov.uk help with fees EX160

## Regulators

**The Financial Conduct Authority (FCA)**
Regulator of insurance brokers. Relevant for complaints about leasehold buildings insurance arrangements. New rules from 31 December 2023 require brokers to treat leaseholders as customers, disclose commissions, and ensure fair value.
- Website: fca.org.uk

**Energy Ombudsman**
Handles unresolved heat network complaints (since 1 April 2025).
- Website: energyombudsman.org

**Ofgem**
Regulator for heat networks in Great Britain (since 27 January 2026).
- Website: ofgem.gov.uk

## Public records

**Companies House**
Public records of UK companies — directors, accounts, ownership. Free search. Useful for establishing related-party relationships (e.g. insurance broker shared directors with managing agent).
- Website: find-and-update.company-information.service.gov.uk
