# Useful organisations

## Free advisory bodies

**The Leasehold Advisory Service (LEASE)**
Government-funded free advice service for leaseholders. Initial advice is free, including telephone consultations and template letters.
- Website: lease-advice.org
- Telephone advice: weekday business hours

**Leasehold Knowledge Partnership (LKP)**
Charity covering leasehold abuses, sector news, and reform efforts. Useful for context and awareness, not for individual casework.
- Website: leaseholdknowledge.com

**Citizens Advice**
Free, confidential advice on housing and consumer matters.
- Website: citizensadvice.org.uk

**Shelter**
Housing-focused charity, useful for broader housing-related issues.
- Website: shelter.org.uk

## Redress schemes

**The Property Ombudsman (TPO)**
Approved redress scheme for managing agents. Can adjudicate conduct complaints; cannot adjudicate the level or reasonableness of service charges. Most awards are under £500.
- Website: tpos.co.uk

**The Property Redress Scheme (PRS)**
The other approved redress scheme for managing agents. Similar function to TPO.
- Website: theprs.co.uk

## Statutory and court bodies

**First-tier Tribunal (Property Chamber)**
The statutory tribunal for service charge and leasehold disputes in England.
- Website: gov.uk/courts-tribunals/first-tier-tribunal-property-chamber
- Application fee: £114
- Hearing fee: £227

**Money Claims Service (MCOL / OCMC)**
The online portal for issuing County Court money claims, including post-tribunal refund claims.
- Website: moneyclaims.service.gov.uk

**HM Courts and Tribunals Service — fee remission**
Form EX160 for help with court and tribunal fees if on a low income or receiving certain benefits.
- Search: gov.uk help with fees EX160

## Regulators

**The Financial Conduct Authority (FCA)**
Regulator of insurance brokers. Relevant for complaints about leasehold buildings insurance arrangements. New rules from 31 December 2023 require brokers to treat leaseholders as customers, disclose commissions, and ensure fair value.
- Website: fca.org.uk

**Energy Ombudsman**
Handles unresolved heat network complaints (since 1 April 2025).
- Website: energyombudsman.org

**Ofgem**
Regulator for heat networks in Great Britain (since 27 January 2026).
- Website: ofgem.gov.uk

## Public records

**Companies House**
Public records of UK companies — directors, accounts, ownership. Free search. Useful for establishing related-party relationships (e.g. insurance broker shared directors with managing agent).
- Website: find-and-update.company-information.service.gov.uk
