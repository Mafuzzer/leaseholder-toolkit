# Decision tree — phase-by-phase

This is the toolkit at a glance. Use it to orient at any point in the process.

```
Do I have a service charge concern?
    │
    ▼
PHASE 1: Recognise the problem and build evidence
- Categorise (level / conduct / lease itself)
- Document everything in writing
- Decide if it is worth pursuing
    │
    ▼  Yes — it is worth pursuing
PHASE 2: Internal complaints process
- Stage 1 formal complaint
- Stage 2 escalation (if needed)
- 8 weeks from Stage 1: external escalation unlocked
    │
    ▼
What kind of dispute is this?
    │
    ├── Conduct only ──────────────────────────┐
    │                                            │
    │   PHASE 3 (redress)                        │
    │   - File with TPO/PRS                      │
    │   - Limited compensation (most under £500) │
    │   - Conduct findings                        │
    │                                            │
    └── Substance (with or without conduct) ────┐
                                                 │
        PHASE 3 (parallel routes)                │
        - MP for information leverage            │
        - Companies House for evidence           │
        - FCA / Energy Ombudsman as relevant     │
        - LEASE for advice                        │
                                                 │
                                                 ▼
                                    PHASE 4: First-tier Tribunal
                                    - Application under Section 27A
                                    - Apply for Section 20C, Para 5A,
                                      fee reimbursement at outset
                                    - Statement of case + evidence
                                    - Hearing
                                    - Decision (4-6 weeks after hearing)
                                                 │
                                                 ▼  Won (in whole or part)
                                    PHASE 5: Recovery
                                    - Calculate refund + interest
                                    - Formal demand
                                    - County Court if necessary
                                    - Watch future demands
                                                 │
                                                 ▼  Optional
                                    Consider Right to Manage if dispute
                                    reveals deeper structural issue
                                    with management
```

Reminder: stop at any phase if continuing is no longer worth it. The decision to not proceed is as legitimate as the decision to continue.

## Time and cost summary

| Phase | Duration | Cost |
|---|---|---|
| Phase 1 | 2 weeks – 2 months | Free |
| Phase 2 | 2 – 5 months | Free |
| Phase 3 | Parallel | Free (mostly) |
| Phase 4 | 6 – 12 months | £114 + £227 + ~100 hours |
| Phase 5 | 1 – 4 months | £80-£115 court fee if needed |
| **Total** | **18 months – 2+ years** | **~£440-£505 mandatory, recoverable if won** |

Time investment: 75–180 hours of leaseholder's own time, not recoverable.
