# Glossary

**Administration charge.** A charge payable under the lease for a specific landlord action — e.g. processing a sale, granting a consent, providing information. Variable administration charges are subject to the reasonableness test under Schedule 11 of the Commonhold and Leasehold Reform Act 2002.

**Asset management plan.** A document setting out anticipated major works and capital expenditure for a building over a multi-year period. The basis for justifying reserve fund contributions.

**Bundle.** The agreed set of documents, paginated and indexed, used by both parties at a tribunal hearing.

**Case management conference (CMC).** A short procedural hearing, often by video or telephone, where the tribunal gives directions and the parties can raise procedural questions.

**Collective enfranchisement.** The right of qualifying leaseholders to buy the freehold of their building. Different from Right to Manage.

**Directions.** The tribunal's procedural orders telling each party what to do and by when.

**Final Response / Final Viewpoint letter.** The formal end of the managing agent's internal complaints process.

**First-tier Tribunal (Property Chamber).** The statutory tribunal that decides service charge disputes and other leasehold matters in England.

**Freeholder.** The owner of the freehold interest in the building. Often, but not always, the respondent in tribunal proceedings. Where the lease is tripartite and names a separate management company, that company is usually the party entitled to demand the service charge — and the correct respondent.

**Leaseholder / lessee.** The person holding a long lease (typically more than 21 years) of a flat.

**Managing agent.** The company that manages the building day to day. Usually appointed by the freeholder or by an RTM company — but under a tripartite lease the management company is a party to the lease in its own right, not a contractor, and can be the correct respondent.

**Paragraph 5A order.** An order under Schedule 11 of the Commonhold and Leasehold Reform Act 2002 reducing or extinguishing the landlord's right to recover costs as administration charges.

**Particulars of claim.** The factual basis of a County Court claim, set out in a structured form.

**Pre-action protocol.** The expectation that parties attempt to resolve a dispute through correspondence before issuing court proceedings.

**Property Ombudsman (TPO).** One of two government-approved redress schemes for managing agents.

**Property Redress.** The other government-approved redress scheme for managing agents, formerly the Property Redress Scheme. Best avoid the old abbreviation "PRS" — outside this context it usually means private rented sector.

**Qualifying tenant.** For Right to Manage, a leaseholder whose lease was originally granted for more than 21 years.

**Reserve fund / sinking fund.** A pool of money built up over time through service charges, intended to fund major future works.

**Right to Manage (RTM).** A statutory right under the Commonhold and Leasehold Reform Act 2002 allowing qualifying leaseholders to take over management of their building from the landlord, without proving fault.

**Section 19 LTA 1985.** The statutory test that service charges must be reasonably incurred and that services or works must be of a reasonable standard.

**Section 20 LTA 1985.** The consultation requirements for major works and long-term agreements above specified thresholds (£250 per leaseholder for major works, £100/year for long-term agreements over 12 months).

**Section 20B LTA 1985 — the 18-month rule.** If a cost was incurred more than 18 months before the demand for it was served on you, you don't have to pay that part of the charge. The exception: if the landlord notified you in writing within those 18 months that the cost had been incurred and that you'd be asked to contribute. Useful against late bills and balancing charges; it doesn't apply to a budget demanded in advance.

**Section 20C LTA 1985.** An order preventing the landlord from recovering its costs of tribunal proceedings through service charges.

**Section 21 LTA 1985.** The right to request a written summary of relevant costs from the landlord.

**Section 21B LTA 1985.** The requirement that every service charge demand be accompanied by a prescribed summary of leaseholders' rights and obligations.

**Section 22 LTA 1985.** The right to inspect the supporting documents behind a Section 21 summary — accounts, receipts, invoices — and take copies. **The request must be made in writing within six months of obtaining the summary (s.22(2)). That deadline cannot be extended by anyone.**

**Section 27A LTA 1985.** The statutory route by which leaseholders apply to the tribunal for a determination on service charges. The jurisdiction is declaratory: the tribunal decides what is payable. It cannot order repayment of sums already paid — that takes a County Court claim.

**Service charge.** The amount payable by leaseholders for services, repairs, maintenance, insurance, and management of the building, as provided for under the lease.

**Statement of case.** The substantive document setting out a party's position at tribunal, more detailed than the application form.

**Statement of truth.** A signed declaration that the facts in a document are true to the best of the signatory's knowledge and belief.

**Stage 1 / Stage 2.** Stages of the typical managing agent complaints process, ending in a Final Response and (potentially) referral to a redress scheme.

**Strike out.** A procedural step where the tribunal dismisses an application or part of an application without considering it on the merits.

**Tribunal Procedure (First-tier Tribunal) (Property Chamber) Rules 2013.** The procedural rules governing the First-tier Tribunal (Property Chamber). Statutory Instrument 2013/1169.

**Section 81 Housing Act 1996.** The protection against forfeiture over a service charge. A landlord cannot forfeit the lease, or serve a section 146 notice to start the process, unless the charge has been finally determined by a court or tribunal, or admitted by the leaseholder. Where it was determined, the landlord must then wait a further 14 days; where it was admitted, there is no waiting period at all. It does not stop the ordinary consequences of arrears (interest, administration charges, a county court claim).

**Withholding payment.** Refusing to pay a service charge demand. Generally not advisable except in narrow circumstances. "Pay under protest" is usually the safer approach. Note that not paying does not put the lease at immediate risk — see Section 81 Housing Act 1996 — but it does expose you to arrears, interest and court proceedings.
