# Leasehold Disputes — Claude Skill

A Claude skill for helping someone navigate a service charge dispute in England with their freeholder or managing agent.

## What this is

This skill turns the Leaseholder's Toolkit (the comprehensive 30,000-word PDF) into something a leaseholder can *talk to*. Where the toolkit is a static reference document, this skill is the conversation around it — Claude using the toolkit's framework to help a specific person think through their specific situation.

The skill is grounded in the same content as the toolkit but operates differently:

- **Toolkit:** Read like a book, start to finish or by section. Static.
- **Skill:** Loaded by Claude when triggered. Adapts to the user's actual situation. Pulls templates and guidance as needed.

## Folder structure

```
leasehold-skill/
├── SKILL.md                           ← The main file Claude reads
├── README.md                          ← This file
├── templates/
│   ├── A1_Stage_1_complaint.md        ← Stage 1 complaint letter
│   ├── A2_Stage_2_escalation.md       ← Stage 2 escalation
│   ├── A3_MP_letter.md                ← Letter to MP
│   ├── A4_Section_21_request.md       ← Summary of costs request
│   ├── A5_Section_22_request.md       ← Inspection of documents
│   ├── A6_Tribunal_application.md     ← What to include in application
│   ├── A7_Statement_of_case_structure.md
│   ├── A8_Witness_statement_structure.md
│   ├── A9_Formal_demand_letter.md     ← Post-tribunal demand
│   ├── A10_County_Court_particulars.md
│   └── A11_Settlement_confirmation_email.md
└── reference/
    ├── glossary.md                    ← Key terms
    ├── organisations.md               ← Useful contacts
    └── decision_tree.md               ← Phase-by-phase flow
```

## How to use

### Option 1: Personal Claude project

1. Create a new Project in Claude (claude.ai)
2. Upload the `leasehold-skill/` folder as project knowledge
3. The skill will be available within that project for any conversation

### Option 2: Anthropic Skills system

If/when Anthropic offers public skill distribution, this skill can be submitted following their submission process. See https://docs.claude.com for current guidance.

### Option 3: Share the folder directly

The skill is just markdown. Anyone with Claude Pro and a Project can use it by uploading these files.

## What the skill does

When triggered (by mentions of service charges, managing agents, freeholders, tribunals, the specific statutory provisions, or many phrasings of common leaseholder concerns), Claude will:

1. Help locate the person in the dispute timeline (Phase 1-5)
2. Suggest the right routes for their specific situation (not just every available route)
3. Pull relevant templates from the templates folder
4. Walk them through tribunal preparation, statement of case structure, witness statements
5. Help with post-tribunal recovery calculations
6. Be honest about costs (time, money, emotional) and when stopping is the right call

## What it doesn't do

- Provide formal legal advice (always points to qualified advice for unusual or high-value cases)
- Cite specific case law (risk of error too high; sticks to statutory framework)
- Replace LEASE for free professional guidance
- Push the user toward maximum confrontation — the user is the decision-maker

## Companion to the toolkit

This skill works alongside the Leaseholder's Toolkit (the PDF). The toolkit is the comprehensive reference; the skill is the conversational application of it. Either can stand alone, but they're stronger together — someone who reads the toolkit will get more out of conversations with the skill, and someone using the skill can be pointed to the toolkit for fuller treatment of any phase.

## Notes

- Content is current to mid-2026 and reflects the LFRA 2024 implementation status as of that date
- LFRA 2024 is being implemented in stages — some provisions verified effective (Sections 49 and 50, RTM changes from 3 March 2025), others still awaited
- Heat network regulation under Ofgem effective 27 January 2026
- FCA insurance broker rules effective 31 December 2023
- This is not legal advice. Where situations are unusual, complex, or high-value, qualified professional advice is essential.
