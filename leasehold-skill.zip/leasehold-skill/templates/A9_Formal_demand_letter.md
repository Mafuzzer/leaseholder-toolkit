# Template: Formal demand letter for refund (post-tribunal)

**When to use:** Once the tribunal has issued its decision and the appeal period (28 days) has passed without challenge.

---

**Subject:** Refund of overpaid service charges — [PROPERTY ADDRESS] — Tribunal case [REFERENCE]

Dear [MANAGING AGENT / FREEHOLDER],

I am writing to request a refund of overpaid service charges, in light of the First-tier Tribunal (Property Chamber) decision dated [DATE] under case reference [REFERENCE].

**The Tribunal's findings:**

The Tribunal determined that the following amounts were not payable:

1. [ITEM 1] for year [YEAR]: £[AMOUNT]
2. [ITEM 2] for year [YEAR]: £[AMOUNT]
3. [ITEM 3] for year [YEAR]: £[AMOUNT]

**Calculation of refund due:**

| Item | Amount paid | Date paid | Disallowed | Days outstanding | Interest at 8% |
|---|---|---|---|---|---|
| [ITEM 1] | £X | [DATE] | £Y | [N] | £Z |
| [ITEM 2] | £X | [DATE] | £Y | [N] | £Z |
| **Subtotals** | | | **£[A]** | | **£[B]** |

Tribunal application and hearing fees (per Tribunal direction): £[C]

**Total amount due: £[A + B + C]**

Interest is claimed at the statutory rate of 8% per annum from the date of payment, in accordance with Section 69 of the County Courts Act 1984.

**Section 20C and Paragraph 5A orders:**

I note that the Tribunal made orders under Section 20C of the Landlord and Tenant Act 1985 and Paragraph 5A of Schedule 11 to the Commonhold and Leasehold Reform Act 2002 preventing recovery of the landlord's costs of the proceedings through service charges or as administration charges. I would be grateful for confirmation that no element of the costs of these proceedings will be passed to leaseholders.

**Payment:**

Please make payment of £[TOTAL] to the following account by [DATE — typically 14 to 21 days from sending]:

[BANK ACCOUNT DETAILS]

If a credit to the service charge account is preferred to a cash refund, please confirm in writing that the credit has been applied, in the full amount including interest, and provide documentary confirmation.

If payment is not received by [DATE], I will pursue recovery through the County Court without further notice.

Yours faithfully,

[YOUR NAME]
[DATE]

---

## Calculating interest

For each disallowed payment:
- Take the amount and the date paid
- Calculate the number of days from the date paid to today
- Apply: principal × 0.08 × (days / 365)

Example: £709.81 paid on 1 December 2023, demand sent 1 May 2026 — 882 days exactly.
Interest = £709.81 × 0.08 × (882/365) = £137.22

Where a disallowed amount was paid in instalments, split it across the instalment dates and calculate each separately. Interest runs on each payment from the date that payment was made. Do not run it on the whole amount from the earliest date, and do not claim the whole amount again on each later date — that counts the same money twice. Count the days with a date calculator; do not estimate.

Show the workings in your demand letter and any subsequent claim. The County Court will accept calculations presented in this format.
