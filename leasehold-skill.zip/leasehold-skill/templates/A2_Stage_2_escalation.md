# Template: Stage 2 escalation letter

**When to use:** When the Stage 1 response has been received and is unsatisfactory, or when the Stage 1 timeframe has elapsed without a substantive response.

---

**Subject:** Stage 2 escalation — [PROPERTY ADDRESS] — Reference [STAGE 1 REFERENCE]

Dear [Senior Manager / Complaints Team],

I am writing to escalate my complaint to Stage 2 of [MANAGING AGENT]'s complaints procedure.

**Background:**
- Stage 1 complaint filed: [DATE]
- Stage 1 reference: [REFERENCE]
- Stage 1 response received: [DATE, OR "NOT YET RECEIVED"]

**Why the Stage 1 response is unsatisfactory:**

1. [SPECIFIC FAILURE — e.g. "The Stage 1 response did not address the question of why the reserve fund contribution increased by £X without supporting justification, despite this being the central issue raised."]

2. [SPECIFIC FAILURE — quote the inadequate Stage 1 reply where relevant. "The Stage 1 response stated that 'the reserve fund is held for future works.' This does not engage with my specific request for a costed schedule of anticipated works."]

3. [SPECIFIC FAILURE, IF APPLICABLE]

**What I am asking for at Stage 2:**

- A substantive response to each of the Stage 1 issues, addressed at a senior management level
- The specific documents previously requested: [LIST]
- [ANY SPECIFIC ACTION]

I would also confirm that, in line with The Property Ombudsman's published procedures, eight weeks from the date of my Stage 1 complaint will pass on [DATE 8 WEEKS AFTER STAGE 1]. If a satisfactory final response has not been received by that date, I reserve the right to refer the matter to the redress scheme.

Yours faithfully,

[YOUR NAME]
[DATE]

---

**Things to customise:**

- Be specific about *why* the Stage 1 response was unsatisfactory. "I am dissatisfied" is not enough.
- Quote the Stage 1 response where relevant — it puts the agent's actual words on the record.
- The 8-week deadline reference is genuine procedural leverage. Use it.
