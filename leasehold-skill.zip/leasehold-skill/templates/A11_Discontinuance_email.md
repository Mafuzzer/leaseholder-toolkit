# Template: Discontinuance email (after payment received)

**When to use:** Once a payment or credit has cleared, discontinue the County Court claim. Send this to the defendant before formally discontinuing through the Money Claims Service portal.

**Critical:** Do not discontinue until the payment has cleared in your account. Discontinuance closes off the formal route to enforcement.

---

**Subject:** Notice of discontinuance — Claim [CLAIM NUMBER]

Dear [DEFENDANT'S SOLICITOR / DEFENDANT],

Further to your payment / credit of £[AMOUNT] received on [DATE], I write to confirm that the principal claim has been satisfied.

I will discontinue the above claim through the Money Claims Service on a no-costs basis (each party to bear its own costs), to be processed in the next [TIMEFRAME].

Please confirm by return that you accept the discontinuance on this basis.

Yours faithfully,

[YOUR NAME]
[DATE]

---

## After sending

1. Wait for confirmation from the defendant
2. Discontinue formally through the Money Claims Service portal
3. Confirm to the court that the discontinuance has been processed
4. Keep a permanent record of the closed claim in your file
