# Template: Stage 1 formal complaint letter

**When to use:** When you have decided to escalate from informal communication to a formal complaint with the managing agent. Send by email to the managing agent's complaints address, with anyone at the agent who has been your point of contact copied in.

---

**Subject:** Formal Stage 1 complaint — [PROPERTY ADDRESS]

Dear [Complaints Team / Named Person],

I am writing to raise a formal Stage 1 complaint in accordance with [MANAGING AGENT]'s complaints procedure.

**My details:**
- Name: [YOUR NAME]
- Property: [FULL ADDRESS, INCLUDING FLAT NUMBER AND POSTCODE]
- Reference (if known): [SERVICE CHARGE OR ACCOUNT REFERENCE]

**The substance of the complaint:**

1. [SHORT, FACTUAL DESCRIPTION OF THE FIRST ISSUE — e.g. "The reserve fund contribution for service charge year 2024-25 has been demanded at £X. Despite written requests on [DATES], no asset management plan, condition survey, or schedule of anticipated works has been provided to justify this level of contribution."]

2. [SHORT, FACTUAL DESCRIPTION OF THE SECOND ISSUE]

3. [SHORT, FACTUAL DESCRIPTION OF THE THIRD ISSUE, IF APPLICABLE]

**What I am asking for:**

- A substantive written response to each of the issues raised above
- The supporting documents I have previously requested but not yet received, namely: [LIST]
- [ANY SPECIFIC ACTION YOU ARE ASKING FOR, e.g. "A revised service charge demand reflecting the corrections identified"]

Please confirm receipt of this complaint and provide the case reference number. I look forward to your substantive response within the timeframe set out in your complaints procedure.

Yours faithfully,

[YOUR NAME]
[DATE]

---

**Things to customise:**

- Be specific about each issue. Generic complaints get generic responses.
- Reference dates. "Despite my email of 14 March 2026" carries more weight than "Despite previous emails."
- State what would resolve the issue. Vague complaints invite vague resolutions.
- Keep emotional language out. The complaint will be more effective for it.
