# Template: Witness statement — structural skeleton

**When to use:** Witness statements are first-person accounts of what you (or another witness) directly observed or experienced. They go in the bundle as evidence.

**Important:** Witness statements from other leaseholders in your building are particularly powerful for management fee challenges or pattern evidence. If three other leaseholders sign witness statements describing similar experiences — same communication failures, same building issues, same concerns about the same charges — this transforms an individual complaint into evidence of a systemic problem.

---

## Structure

### 1. Heading

> Witness Statement of [FULL NAME]
> Case ref: [TRIBUNAL CASE REFERENCE]
> Made on behalf of: [APPLICANT / RESPONDENT]
> Date: [DATE]

### 2. Personal introduction

> 1. I am [FULL NAME] of [ADDRESS]. I am the leaseholder of [PROPERTY ADDRESS] and the Applicant in these proceedings. The matters set out in this statement are within my own knowledge unless otherwise stated, and are true to the best of my knowledge and belief.

### 3. Background context

> 2. I purchased the leasehold of [PROPERTY] in [DATE]. The property is one of [NUMBER] flats in [BUILDING NAME / DESCRIPTION], managed by [MANAGING AGENT] on behalf of [FREEHOLDER].
>
> 3. [ANY RELEVANT BACKGROUND ON YOUR INVOLVEMENT WITH THE BUILDING.]

### 4. Chronological account of relevant events

Numbered, dated, factual paragraphs. One event per paragraph where possible.

> 4. On [DATE], I received the service charge demand for year 2024-25 from [MANAGING AGENT]. The reserve fund contribution was stated as £1,419.61, an increase of £X compared to the previous year.
>
> 5. On [DATE], I sent an email to [NAMED CONTACT] at [MANAGING AGENT], asking for an explanation of the increase and for the asset management plan supporting the reserve fund. A copy of that email is at page [X] of the Applicant's bundle.
>
> 6. I received no response within [TIMEFRAME]. On [DATE], I sent a follow-up email...

Continue chronologically until you reach the present.

### 5. Statement of truth

> I believe that the facts stated in this witness statement are true.
>
> Signed: ______________________
> Name: [FULL NAME]
> Date: [DATE]

---

## Things to remember

- **Use first person.** "I sent the email" not "An email was sent."
- **Stick to facts you personally know.** Not opinion, speculation, or rumour.
- **Cross-reference exhibits** (emails, letters, documents) to the bundle page numbers.
- **Be specific with dates.** "On 14 March 2026" not "in early 2026."
- **Don't characterise.** "The Respondent did not reply" is a fact. "The Respondent ignored me" is a characterisation. Stick to the fact.
- **Keep it focused.** Only include events relevant to the issues at the tribunal.

## For witness statements from other leaseholders

If you are getting other leaseholders to sign witness statements:

- Each statement should be in their own voice and based on their own experience
- They should be willing to attend the hearing if required (though many cases proceed on written statements alone)
- Their statements should focus on what *they* directly experienced — not on what they were told by you
- The statement of truth must be signed and dated by them personally
