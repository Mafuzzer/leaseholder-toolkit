# Template: Section 22 request — inspection of supporting documents

**When to use:** Once you have received a Section 21 summary, to inspect the underlying invoices, receipts, and accounts.

**You have six months — diarise it now.** The request has to be made within six months of receiving the Section 21 summary. Miss it and the right is gone. The trap is an obvious one once you see it: sitting down to read and analyse the summary properly is exactly what eats the six months. Send this request early. You can always inspect later; you can't extend the deadline.

---

**Subject:** Request under Section 22 of the Landlord and Tenant Act 1985 — [PROPERTY ADDRESS]

Dear [LANDLORD / MANAGING AGENT],

Further to the summary of relevant costs provided in response to my Section 21 request dated [DATE], I am writing to request, pursuant to Section 22 of the Landlord and Tenant Act 1985, reasonable facilities for inspecting the accounts, receipts, and other documents supporting that summary, and for taking copies or extracts from them.

The Act requires you to make these facilities available within one month of this request, for a period of two months. Inspection must be made available free of charge; reasonable charges may be made for copying.

Please contact me to arrange a mutually convenient time and location for the inspection. I would be grateful if the inspection could be arranged for a date within the next four weeks.

Yours faithfully,

[YOUR NAME]
[DATE]
