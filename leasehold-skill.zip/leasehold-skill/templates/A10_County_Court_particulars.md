# Template: County Court particulars of claim (Money Claim Online)

**When to use:** If the formal demand is not paid by the deadline. File the claim through the Money Claims Service (moneyclaims.service.gov.uk).

The online form has a character limit; the particulars below show the structure to fit within it.

---

## Particulars of Claim

1. The Claimant is the leaseholder of [PROPERTY ADDRESS] under a lease dated [DATE OF LEASE].

2. The Defendant is the freeholder/landlord of the property and was the Respondent in First-tier Tribunal (Property Chamber) proceedings under reference [TRIBUNAL CASE REFERENCE].

3. By a decision dated [DATE], the Tribunal determined that the following service charges were not payable: [BRIEF SUMMARY OF DISALLOWED ITEMS AND AMOUNTS].

4. The Claimant had previously paid the disputed sums totalling £[AMOUNT].

5. The Claimant gave the Defendant formal notice of the refund due by letter dated [DATE OF DEMAND LETTER]. The Defendant has failed to pay.

6. The Claimant claims:
   - The principal sum of £[AMOUNT]
   - Interest at 8% per annum from the dates of payment under Section 69 of the County Courts Act 1984, calculated as £[INTEREST] to the date of issue and continuing at £[DAILY RATE] per day until judgment or earlier payment
   - Reimbursement of tribunal fees of £[FEES] as ordered by the Tribunal
   - Court fees and any other recoverable costs

Statement of truth: The Claimant believes that the facts stated in these Particulars of Claim are true.

---

## Things to remember

- The defendant's name must match exactly. Check Companies House for the registered company name if needed.
- Attach the tribunal decision as a supporting document.
- Keep the particulars factual. The merits have already been determined by the tribunal; this claim enforces that determination.
- Court fees: typically £80-£115 for service charge refund claims under £3,000.
- Most service charge refund claims settle before any defence is filed — the tribunal decision makes the merits very predictable.

## What happens after issue

- Defendant has 14 days to respond (28 if they file an acknowledgement of service first)
- They can: pay (settlement), defend the claim, or default (no response → you can apply for default judgment)
- Most claims settle before defence
