# Template: County Court particulars of claim (Money Claims)

**When to use:** If the formal demand is not paid by the deadline. File the claim through Money Claims (moneyclaims.service.gov.uk).

The online form has a character limit; the particulars below show the structure to fit within it.

**Before you start — check who you are actually suing.** Name whoever took your money and has to give it back under the lease. That is often *not* the freeholder. Many leases are tripartite — freeholder, management company, leaseholder — and it's the management company that collects the service charge and holds the funds. It can be the right defendant even though the freeholder was the party named at the tribunal.

Two things to look at before you issue: who the lease names as the manager, and who the demands told you to pay. Getting this wrong is fixable, but it costs you weeks and hands the other side an argument about costs.

---

## Particulars of Claim

1. The Claimant is the leaseholder of [PROPERTY ADDRESS] under a lease dated [DATE OF LEASE].

2. The Defendant is [the management company / the landlord] under the lease and received the service charge payments claimed. [If a different party was the Respondent at the tribunal, add: The Respondent in the First-tier Tribunal (Property Chamber) proceedings under reference [TRIBUNAL CASE REFERENCE] was [NAME].]

3. By a decision dated [DATE], the Tribunal determined that the following service charges were not payable: [BRIEF SUMMARY OF DISALLOWED ITEMS AND AMOUNTS].

4. The Claimant had previously paid the disputed sums totalling £[AMOUNT].

5. The Claimant gave the Defendant formal notice of the refund due by letter dated [DATE OF DEMAND LETTER]. The Defendant has failed to pay.

6. The Claimant claims:
   - The principal sum of £[AMOUNT]
   - Interest at 8% per annum from the dates of payment under Section 69 of the County Courts Act 1984, calculated as £[INTEREST] to the date of issue and continuing at £[DAILY RATE] per day until judgment or earlier payment
   - Reimbursement of tribunal fees of £[FEES] as ordered by the Tribunal
   - Court fees and any other recoverable costs

Statement of truth: The Claimant believes that the facts stated in these Particulars of Claim are true.

---

## Things to remember

- The defendant's name must match exactly. Check Companies House for the registered company name if needed.
- Attach the tribunal decision as a supporting document.
- Keep the particulars factual. The merits have already been determined by the tribunal; this claim enforces that determination.
- Court fees: £35-£115 for claims under £3,000. The fee is set on what you claim, interest included, so interest can push you into a higher band. A claim for £1,472.55 of disallowed charges plus £277.76 of interest is a claim for £1,750.31 — that is the £1,500.01–£3,000 band, £115, not the £80 the principal alone would suggest.
- Most service charge refund claims settle before any defence is filed — the tribunal decision makes the merits very predictable.

## What happens after issue

- Defendant has 14 days to respond (28 if they file an acknowledgement of service first)
- They can: pay (settlement), defend the claim, or default (no response → you can apply for default judgment)
- Most claims settle before defence
