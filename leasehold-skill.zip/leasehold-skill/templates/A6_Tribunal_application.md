# Template: Tribunal application — what to include

**When to use:** When preparing an application to the First-tier Tribunal (Property Chamber) under Section 27A of the Landlord and Tenant Act 1985.

The official form is **Leasehold 3**, *"Apply for determination of liability to pay and/or reasonableness of service charges"* (version 04.25). Search gov.uk for "Leasehold 3".

---

## Sections of the form

**Applicant**
Your name, address, and contact details. Use the address of the property in question.

**Respondent**
The party entitled under the lease to demand and enforce payment of the service charge. Do not assume it is the freeholder. Section 30 LTA 1985 treats anyone with a right to enforce payment as a "landlord" for these purposes, so a management company named as a party to a tripartite lease can be the respondent in its own right — and often is the right one. Read the parties clause of the lease, then check whose name is on the demands and who the money was paid to. Naming the wrong respondent is a procedural point the other side will use to delay or strike out.

**Property**
Full address, lease details, your interest in the property.

**Issues**
A clear list of the specific charges you are challenging. Identify each by:
- Service charge year (e.g. 2024-25)
- Item (e.g. "reserve fund contribution")
- Amount (e.g. £1,419.61)

Include a one-line summary of why each is challenged.

**Section 20C and paragraph 5A — two questions near the front**

These are two standalone Yes/No questions on Leasehold 3, on the page before Section 1. Tick Yes to both.

1. An order under Section 20C LTA 1985 that the landlord's costs of these proceedings are not to be recoverable through the service charge
2. An order under Paragraph 5A of Schedule 11 to the Commonhold and Leasehold Reform Act 2002 reducing or extinguishing the landlord's right to recover those costs as an administration charge

**What you ask for in the statement of case**

There is no "orders sought" section on the form, and no box for reimbursement of your tribunal fees.

3. A determination under Section 27A LTA 1985 that the disputed charges are not payable, alternatively that they are payable only in such reduced amount as the Tribunal considers reasonable. This goes in Section 6.4 onwards, which asks for the items of service charge in issue, their value, and the questions you want the tribunal to decide.
4. Reimbursement of the application and hearing fees. Ask for this in the statement of case, and again out loud at the end of the hearing. The tribunal deals with fees at the end of the case. People assume ticking the form covered it. It did not.

**Hearing or paper determination**
Request a hearing unless your case is genuinely simple.

**Fee**
£114 application fee at submission. £227 hearing fee payable later. Apply for fee remission (form EX160) if eligible — receipt of certain benefits or low income.

---

## Critical reminders

- **Tick Section 20C and Paragraph 5A on the form**, then ask for all three — those two plus fee reimbursement — in the statement of case, and say them out loud at the hearing. Forgetting them is genuinely costly: the landlord's costs of fighting the case can otherwise come back to you through future service charges.
- **The hearing fee has a 14-day clock.** When the tribunal requests it, pay within 14 days and quote the exact payment reference given, or the application can be treated as withdrawn under rule 11.
- **Be specific.** Vague challenges to "the 2024 service charge" are too broad. Specific challenges to "the 2024 reserve fund contribution of £X and the 2024 management fee of £Y" are the right level of specificity.
- **Identify the right respondent.** Check the lease and the service charge demands.
