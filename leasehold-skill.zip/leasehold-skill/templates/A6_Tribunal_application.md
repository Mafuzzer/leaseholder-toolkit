# Template: Tribunal application — what to include

**When to use:** When preparing an application to the First-tier Tribunal (Property Chamber) under Section 27A of the Landlord and Tenant Act 1985.

The official form is *Application for a determination of liability to pay and/or reasonableness of service charges*. Download from the gov.uk First-tier Tribunal Property Chamber pages.

---

## Sections of the form

**Applicant**
Your name, address, and contact details. Use the address of the property in question.

**Respondent**
The freeholder (or whoever is liable to provide services and demand payment under the lease). Get this exactly right by reference to your lease and recent service charge demands. Identifying the wrong respondent is a procedural issue respondents try to use to delay or strike out cases.

**Property**
Full address, lease details, your interest in the property.

**Issues**
A clear list of the specific charges you are challenging. Identify each by:
- Service charge year (e.g. 2024-25)
- Item (e.g. "reserve fund contribution")
- Amount (e.g. £1,419.61)

Include a one-line summary of why each is challenged.

**Orders sought (CRITICAL — do not miss these)**

Include all of the following, even if you think the substantive case is the main thing:

1. A determination under Section 27A LTA 1985 that the disputed charges are not payable, alternatively that they are payable only in such reduced amount as the Tribunal considers reasonable
2. An order under Section 20C LTA 1985 that the landlord's costs of these proceedings are not to be recoverable through the service charge
3. An order under Paragraph 5A of Schedule 11 to the Commonhold and Leasehold Reform Act 2002 reducing or extinguishing the landlord's right to recover costs as administration charges
4. Reimbursement of the application and hearing fees

**Hearing or paper determination**
Request a hearing unless your case is genuinely simple.

**Fee**
£114 application fee at submission. £227 hearing fee payable later. Apply for fee remission (form EX160) if eligible — receipt of certain benefits or low income.

---

## Critical reminders

- **Apply for the three orders at the outset** (Section 20C, Paragraph 5A, fee reimbursement). Reiterate them in the statement of case. Restate them at the hearing. Forgetting them is genuinely costly — the landlord's legal costs of fighting the case can otherwise come back to you through future service charges.
- **Be specific.** Vague challenges to "the 2024 service charge" are too broad. Specific challenges to "the 2024 reserve fund contribution of £X and the 2024 management fee of £Y" are the right level of specificity.
- **Identify the right respondent.** Check the lease and the service charge demands.
