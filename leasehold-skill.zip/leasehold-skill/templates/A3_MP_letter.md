# Template: Letter to your MP

**When to use:** When you want to enlist your MP for information leverage or constituent service. MPs accept correspondence at firstname.lastname.mp@parliament.uk. They have a duty of care to constituents regardless of whether they have a specialist interest in leasehold.

---

**Subject:** Constituent matter — service charge dispute — [PROPERTY ADDRESS]

Dear [MR/MS/MRS LASTNAME],

I am writing as a constituent to ask for your assistance with a service charge dispute affecting my home at [PROPERTY ADDRESS, with postcode].

**The situation in brief:**

I am a leaseholder in a [NUMBER]-flat development managed by [MANAGING AGENT NAME], on behalf of [FREEHOLDER NAME]. I am in dispute with the managing agent over [BRIEF DESCRIPTION — e.g. "the level of reserve fund contributions and management fees for service charge years 2024-25 and 2025-26"].

The dispute has now run since [DATE]. I have followed the formal complaints process to Stage 2 and received a Final Response, which I do not consider satisfactorily addresses the substantive issues. The next step would be an application to the First-tier Tribunal (Property Chamber), which I am preparing.

**What I am asking for:**

Specifically, I would be grateful if you could:

1. Write to the relevant Minister at the Ministry of Housing, Communities and Local Government on my behalf, asking for the Government's position on [SPECIFIC ISSUE — e.g. "transparency obligations on managing agents in respect of reserve fund justifications"]

2. Write to [MANAGING AGENT NAME] requesting a substantive response to the outstanding questions raised in my complaint, particularly: [LIST]

3. [ANY OTHER SPECIFIC ASK]

**Documents enclosed:**

- My Stage 1 complaint dated [DATE]
- The Stage 2 Final Response from [MANAGING AGENT] dated [DATE]
- [ANY OTHER KEY DOCUMENT — keep this short, three or four documents at most]

I appreciate the demands on your time and would be grateful for any assistance you can provide. I am happy to provide further detail if helpful.

Yours sincerely,

[YOUR NAME]
[POSTAL ADDRESS — including postcode, MPs only act on letters from constituents in their constituency]
[EMAIL ADDRESS]
[PHONE NUMBER]
[DATE]

---

**Things to customise:**

- Include your full postal address. MPs verify constituency before acting.
- Be specific about what you want them to do. Vague requests get vague responses.
- Keep the letter to one page if possible. Attach documents separately.
- Realistic expectation: the MP will not directly resolve the dispute. The value is in the substantive responses extracted under political pressure, which can become tribunal evidence.
