# Template: Statement of case — structural skeleton

**When to use:** As the structural foundation for your statement of case at the First-tier Tribunal. The statement of case is the substantive document setting out your position; it is more detailed than the application form.

This is a structure, not a fill-in-the-blanks form. Adapt to your specific situation.

---

## Suggested structure

### 1. Introduction

One paragraph identifying the parties, the property, the lease, the application, and the case reference.

### 2. The challenged charges

A clear table or list of every charge being challenged, by year, item, and amount. This is the spine of the case.

| Service charge year | Item | Amount challenged |
|---|---|---|
| 2024-25 | Reserve fund contribution | £1,419.61 |
| 2024-25 | Management fee | £272.98 |

### 3. The grounds of challenge — by item

A subsection for each challenged item. For each item:
- State the challenge
- Identify the evidence relied on (cross-referenced to the bundle)
- Identify the statutory test (typically Section 19 LTA 1985 reasonableness)
- State the relief sought

**Example structure for one item:**

> **3.2 Reserve fund contribution, year 2024-25: £1,419.61**
>
> 3.2.1 The Applicant challenges this contribution as unreasonable.
>
> 3.2.2 The contribution represents a substantial increase from previous years (£X in 2022-23, £Y in 2023-24). No explanation has been provided for the increase.
>
> 3.2.3 The Applicant has requested, on [date 1] and [date 2], a copy of the asset management plan, condition survey, or schedule of major works against which the reserve fund is being collected. No such document has been provided.
>
> 3.2.4 Section 19 of the Landlord and Tenant Act 1985 requires that service charges be reasonably incurred. A reserve fund contribution that cannot be tied to any identified, costed, scheduled programme of works is not reasonably incurred.
>
> 3.2.5 The Applicant therefore seeks a determination that the reserve fund contribution of £1,419.61 for year 2024-25 is not payable, alternatively is payable only in such reduced amount as the Tribunal considers reasonable.

### 4. Pattern evidence (if relevant)

A section setting out wider mismanagement context that supports the individual challenges, particularly relevant for management fee challenges. Includes things like:
- Repeated failures to provide requested information
- Pattern of late or non-existent responses
- Issues raised by other leaseholders in the building
- Breaches of relevant codes of practice

### 5. Statutory framework

A short section identifying the statutory provisions relied on. The Tribunal knows the law; this is for orientation.

Common provisions:
- Section 19 LTA 1985 (reasonableness of service charges)
- Section 20 LTA 1985 (consultation requirements where major works exceed thresholds)
- Section 27A LTA 1985 (jurisdiction of the tribunal)
- Schedule 11 CLRA 2002 (administration charges)

### 6. Supporting evidence

A list of documents relied on, cross-referenced to bundle pages.

### 7. Orders sought

Restate all orders being sought:
- Substantive determination on the challenged items
- Section 20C order
- Paragraph 5A order
- Reimbursement of tribunal fees

### Statement of truth

> "I believe the facts stated in this Statement of Case are true."
>
> Signed: ______________________
> Name: [FULL NAME]
> Date: [DATE]

---

## Phrasing — what works and what doesn't

| Use | Avoid |
|---|---|
| "The Respondent did not address the question raised in the email of [date]" | "The Respondent has been deliberately evasive" |
| "No explanation has been provided" | "They are hiding something" |
| "The Applicant requested X on [date]; no response has been received" | "They never reply to anything" |
| "The contribution represents an increase of £X (Y%) from the previous year" | "The charges are exorbitant" |
| "The Respondent's letter of [date] stated [exact quote or paraphrase]" | "The Respondent claims..." (unsourced) |

The pattern in the right column makes accusations the tribunal cannot verify. The pattern in the left column is factually grounded and lets the tribunal draw its own inferences.

## What to leave out

- Emotional language ("It is outrageous that...")
- Accusations of motive without evidence ("deliberately," "in bad faith")
- Tangential complaints not part of the formal challenge
- Speculation about internal company decision-making
- Long quotations from third parties
- References to the company's wider reputation, Trustpilot reviews, news stories

## General principles

- Number every paragraph
- Cross-reference every factual claim to a bundle page (e.g. "(Bundle p.34)")
- Keep it tight — 10 pages of focused argument beats 40 pages of repetition
- Plain English. No need to write in pretend legal language.
