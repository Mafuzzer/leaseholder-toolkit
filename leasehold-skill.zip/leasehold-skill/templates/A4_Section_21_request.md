# Template: Section 21 request — summary of relevant costs

**When to use:** To request a written summary of service charge costs under Section 21 of the Landlord and Tenant Act 1985.

---

**Subject:** Request under Section 21 of the Landlord and Tenant Act 1985 — [PROPERTY ADDRESS]

Dear [LANDLORD / MANAGING AGENT],

I am the leaseholder of [PROPERTY ADDRESS]. I am writing to request, pursuant to Section 21 of the Landlord and Tenant Act 1985, a written summary of the relevant costs incurred during the accounting period ending [DATE OF MOST RECENT YEAR-END].

Please provide:

- A summary of the costs incurred and the period to which the summary relates
- The total of any amounts received by the landlord in respect of those costs and standing to the credit of any service charge account
- The aggregate of any amounts received on account of service charges and any amounts paid out

Where service charges are payable by tenants of more than four dwellings, please ensure the summary is certified by a qualified accountant in accordance with Section 21(6) of the Act.

The Act requires you to provide this summary within one month of receipt of this request, or within six months of the end of the accounting period to which it relates, whichever is later.

Failure to comply without reasonable excuse is a summary offence under Section 25 of the Act.

I look forward to receiving the summary by [DATE — one month from sending].

Yours faithfully,

[YOUR NAME]
[DATE]
