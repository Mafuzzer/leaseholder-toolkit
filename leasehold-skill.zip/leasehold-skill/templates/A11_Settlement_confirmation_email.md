# Template: Confirming settlement after payment

**When to use:** The other side has paid, or applied a credit, after you issued your County Court claim. This is how you close it down.

## Do not discontinue

Discontinuing sounds like the tidy way to end a claim that's been paid. It isn't, and this is worth understanding before anyone talks you into it.

Discontinuing is how you *abandon* a claim, and the court treats it that way. The moment you discontinue, a costs order in the defendant's favour is **deemed** to have been made — automatically, with no hearing and without the other side even having to ask (CPR 38.6 and 44.9(1)(c)).

Be accurate about how bad that is. On a small claim it is usually not catastrophic: where the claim would fall under the small claims costs rules, those restricted rules govern what can actually be recovered, so you are not exposed to the other side's full legal bill. But you still end up with a costs order against you, and interest runs on it from the day you discontinue. You went to court to recover money and walked away owing some.

What you do instead is simpler and carries none of that. Sign in to your Money Claims account and tell the court the claim has been **settled**.

Two things to know about the settlement route:

- You can only use it if **everything** is settled — the money, the court fee, and the question of who pays the costs of the proceedings. That is why the letter below spells all three out. Don't notify settlement while any of them is still open.
- Notifying settlement stays the claim. The defendant then has a window to object, and if they do, the claim moves out of the online service. So get their written agreement first, which is what the letter is for.

Expect the other side's solicitors to press for discontinuance anyway. It is a reasonable-sounding request that quietly moves a costs risk onto you at the exact moment you have won and just want it finished. Say no, in writing, and say why.

## Before you send

- The money must have cleared, or the credit been applied and confirmed in writing.
- Check what arrived actually covers everything: the principal, the interest, **and** the court fee you paid to issue. If the payment only covers the principal, you have not been paid in full — say so rather than closing the claim.

---

**Subject:** Claim [CLAIM NUMBER] — confirmation of settlement

Dear [DEFENDANT'S SOLICITOR / DEFENDANT],

I acknowledge receipt of £[AMOUNT], [received into my account / credited to my service charge account] on [DATE]. This comprises the principal sum of £[PRINCIPAL], interest of £[INTEREST], and the court issue fee of £[FEE], and satisfies the claim in full.

On that basis the claim is settled in its entirety, including the court fee and the costs of the proceedings, with each party bearing its own costs. I will notify the court accordingly through the Money Claims service.

For the avoidance of doubt, I am not discontinuing the claim. It has been settled by payment.

Please confirm by return that you agree the claim is settled on these terms.

Yours faithfully,

[YOUR NAME]
[DATE]

---

## After sending

1. Sign in to your Money Claims account and tell the court the claim has been **settled**. Do not file a notice of discontinuance.
2. Save the confirmation screen, and keep a copy of this letter with it.
3. If they push back and insist on discontinuance, decline in writing and give the reason: discontinuance carries a costs liability that settlement does not, and the claim has been paid, not abandoned.
4. Keep the whole file. If the same charge reappears on a future demand, this is what you'll need.
