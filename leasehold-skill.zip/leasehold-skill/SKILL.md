---
name: leasehold-disputes
description: Help someone navigate a service charge dispute in England with their freeholder or managing agent — from first noticing a problem through to recovering money after a tribunal win. Use this skill whenever someone mentions a service charge concern, a managing agent or freeholder issue, a Section 20 consultation, a reserve fund query, building insurance premiums, a Stage 1 or Stage 2 complaint, the Property Ombudsman, the First-tier Tribunal (Property Chamber), Section 27A, Section 20C, Right to Manage, or post-tribunal recovery. Trigger it even without the words "service charge" — phrases like "my management company won't respond," "I'm thinking of going to tribunal," "I won my tribunal but they haven't paid," or "I think I'm being overcharged" all warrant it. The person may be early in their dispute, mid-complaint, preparing for tribunal, or post-decision. The skill helps them figure out where they are, what to do next, and what's worth their time.
---

# Leasehold disputes

A skill for helping someone navigate a service charge or related dispute with a freeholder or managing agent in England. The aim is to help them think clearly about their position, choose the right routes for their specific dispute, and avoid wasting time on routes that don't match their situation.

## What this skill is for

A leasehold service charge dispute is a structurally difficult thing. The person you're helping is usually a self-representing leaseholder — a homeowner, not a lawyer — facing a professionally represented counterparty (a freeholder backed by a managing agent backed by specialist solicitors). The asymmetry is real and structural: their evenings and weekends against the other side's billable hours.

Most of what they need is not legal expertise. It is **judgement** about which routes are worth pursuing for their specific situation, and the **discipline** to keep going without losing their grip on what matters.

This skill should help them with both. Not by giving them a script. By helping them think.

## Core principles

### Match the route to the dispute, not the dispute to a route

The single most common mistake leaseholders make is choosing routes that don't actually fit their problem. The redress schemes (TPO / Property Redress) cannot adjudicate the level of charges. The auditor will not find for the leaseholder. Public reviews don't move the substantive question. The MP rarely produces a refund. Each of these is a real route, but each is a tool for a particular kind of job.

Your first job, when someone describes their situation, is to figure out what their dispute is actually *about*:

- **Level / reasonableness of charges** → First-tier Tribunal is the substantive forum
- **Conduct only** (communication failures, complaint handling, code breaches with no substantive charge dispute) → Redress scheme is the substantive forum
- **Both conduct and substance** → Tribunal handles both; redress scheme can run in parallel but is optional
- **A statutory right rather than a dispute** (Right to Manage, lease extension, enfranchisement) → Specialist advice, not this toolkit's territory

Don't accept the person's characterisation of their problem at face value. Many describe a "complaint" when what they have is a substantive challenge to charges. Many describe "I want to sue them" when what they need is the tribunal's reasonableness determination. Help them name what they actually have.

### Honesty about cost is part of the help

Going all the way through this process — Phase 1 to Phase 5 — typically takes 18 months to 2+ years and 75-180 hours of the person's own time. The financial fees are modest (~£396-£506 mandatory, mostly recoverable if they win). The time cost is not recoverable.

If their dispute is under £500, it is usually not worth the effort, and saying so honestly is more helpful than encouraging them to start. If their dispute is part of a building-wide pattern, even a modest individual sum can be worth pursuing because the precedent matters.

The leaseholder is the decision-maker. Your role is to make their decision informed, not to push them toward maximum confrontation.

### The internal complaints process is not where disputes get resolved

Stage 1 and Stage 2 complaints are procedural steps that *unlock* later routes. They very rarely produce substantive resolution. Help the person see this without becoming cynical: complete the steps properly, exhaust the process, and treat it as preparation for the next phase rather than a venue where they will get justice.

After eight weeks from a formal Stage 1 complaint, The Property Ombudsman (or Property Redress) becomes available. After the internal process is exhausted (typically 4-8 weeks of fast-tracking, or the full 8 weeks waited out), the tribunal route is fully unlocked.

**The window also closes, and this is the one people miss.** The complaint has to reach the Ombudsman within **twelve months** of the agent's final viewpoint letter. There's a second twelve-month limit as well: the Ombudsman won't look at something that happened more than twelve months before the person first complained to the agent in writing. Neither limit has any published discretion to extend.

So whenever someone is weighing up whether to escalate, get both dates into their diary before anything else. This matters most for the people who are being careful — someone who takes six months to gather evidence and think it over can find the door has quietly shut.

### Pay under protest, never withhold

The instinct to withhold service charges is understandable but dangerous. The right approach is to **pay under protest** — in writing, on a "without prejudice" basis pending resolution — and pursue refunds through tribunal afterwards.

Be accurate about the risk, in both directions, because people make bad decisions when they're frightened.

Not paying is genuinely bad: arrears, interest, administration charges, a county court claim, and damage to their credit file.

But it does not mean losing the flat. A landlord cannot forfeit a lease over a service charge — or even start the process by serving a section 146 notice — unless a court or tribunal has finally determined that the amount is payable, or the leaseholder has admitted that it is. That protection is section 81 of the Housing Act 1996, and it exists precisely because the threat was being used to extract payment of charges people were entitled to question.

One detail inside that is worth warning them about. Where the amount was **determined**, the landlord has to wait a further 14 days on top. Where the leaseholder simply **admitted** it, there is no waiting period at all — the protection falls away immediately. And an admission need not be formal: agreeing a figure in an email, or saying "I know I owe it, I just can't pay right now", can be enough. So dispute in writing, pay under protest, and never concede a figure you have not decided to concede.

Hold both halves of that. Fear of forfeiture is what makes people pay charges they could have challenged; casualness about arrears is what gets them into court.

If someone tells you they're considering withholding payment, walk them away from it carefully. The narrow exceptions (such as a non-Section-21B-compliant demand) are technical defences, not general permission to refuse payment of disputed charges.

### The three orders to apply for at tribunal

If the person is preparing or considering a tribunal application, this is the single most consequential thing to make sure they don't miss:

1. **Section 20C order** under the Landlord and Tenant Act 1985 — prevents the landlord recovering legal costs of the tribunal proceedings through future service charges
2. **Paragraph 5A order** under Schedule 11 of the Commonhold and Leasehold Reform Act 2002 — prevents recovery as administration charges (the other recovery route)
3. **Reimbursement of tribunal fees** under Rule 13

These must be applied for *at the outset* in the application form, *reiterated* in the statement of case, and *restated* at the hearing. They are easy to forget in the heat of arguing the substance, and forgetting them is genuinely costly.

One practical trap on the third one: there is no box for fee reimbursement on the application form. The first two are tick-box questions near the front of the form, but fees have to be asked for in the statement of case and then said out loud at the end of the hearing. People assume that ticking the form covered it, and it didn't.

### Tribunal preparation is mostly discipline, not law

The tribunal is designed to be accessible to self-representing leaseholders. The forms are in plain English. The hearings are informal-ish. Panels are professional and fair.

What wins cases is:
- **Specificity** — the disputed items named clearly with reasons, not vague complaints
- **Evidence** — documents in a paginated bundle, witness statements (especially from other leaseholders in the building)
- **Discipline at the hearing** — speak to the panel not the respondent, don't interrupt, don't raise voice, refer to specific bundle pages, willing to concede minor points
- **Restating the orders sought** at every stage — application form, statement of case, opening, closing

What loses cases is:
- Emotional language, accusations of motive without evidence, vague generalisations about "exorbitant" charges, tangential complaints, anything that signals the applicant cannot separate substance from feeling

Help the person prepare for both: the substance of their case, and the conduct of presenting it.

### A tribunal win does not return their money

This catches almost everyone off guard. The tribunal *determines* what was reasonable. It does not transfer money. If they have already paid disputed charges, they need to:

1. Calculate what's owed (principal + 8% statutory interest from dates of payment + tribunal fees if reimbursement was ordered)
2. Send a formal demand letter
3. If unpaid in 14-21 days, file a Money Claim through moneyclaims.service.gov.uk
4. Once the money arrives, tell the court the claim has been **settled** — do not discontinue it (see below)

Many landlords will offer a credit to the service charge account rather than a cash refund. Whether this is acceptable depends on the leaseholder's situation — often fine for someone staying in the property, more complicated for someone selling.

### Settled, not discontinued

When the money finally arrives, there is a right way and a wrong way to close the court claim, and the wrong one is the one that sounds tidier.

**Do not let them discontinue.** Discontinuing is how you abandon a claim, and the court treats it that way: the moment they discontinue, a costs order in the defendant's favour is *deemed* to have been made, automatically, with no hearing and without the other side asking (CPR 38.6 and 44.9(1)(c)).

Be accurate about the scale of it rather than frightening them. On a small claim the restricted small-claims costs rules govern what can actually be recovered, so this is not usually a ruinous sum. But they still end up with a costs order against them, with interest running from the day they discontinue — having gone to court to recover money and come away owing some.

What they do instead is simpler: sign in to the Money Claims account and tell the court the claim has been **settled**. Two conditions attach. Everything has to be settled — the money, the court fee, and who bears the costs of the proceedings — so all three need nailing down in the correspondence first. And notifying settlement stays the claim, with a window for the defendant to object, so get their written agreement before notifying.

Expect the other side's solicitors to ask for discontinuance anyway. It is a reasonable-sounding request that quietly shifts a costs risk onto the leaseholder at the exact moment they've won and want it over with. Help them decline it in writing and say why.

### The 18-month rule (Section 20B)

Worth checking whenever someone is looking at a bill for work already done — a balancing charge, a late invoice, a demand that turns up long after the event.

If the cost was incurred more than 18 months before the demand landed, they don't have to pay it. There's one exception: if the landlord wrote to them within those 18 months to say the cost had been incurred and they'd be asked to contribute, the clock doesn't help them.

This is worth knowing because it isn't an argument about whether a charge was fair — it's a bar. If it applies, the money simply isn't owed, and nobody has to win a debate about value.

It does *not* apply to an ordinary annual budget demanded in advance, so don't go looking for it in a standard budget dispute. Reach for it when the timing looks odd.

## Process — figuring out where they are

When someone first describes their situation, your first job is to locate them in the process. Ask, where you don't already know:

**Where is the property?** Ask this before giving any procedural advice. Everything in this skill is England. Wales shares most of the underlying statute but not the machinery — service charge disputes there go to the Residential Property Tribunal Wales, on different forms, fees and rules, and the Property Chamber rules cited here do not apply. Scotland and Northern Ireland have separate legal systems and nothing here transfers. If the property is not in England, say so plainly and point them to residentialpropertytribunal.gov.wales or to local advice.

**Have they already paid the disputed charges?**
- If yes → they are looking at recovery (Phase 5 if post-tribunal, otherwise the question is whether to challenge)
- If no → they should pay under protest while challenging, not withhold

**Have they put their concerns in writing yet?**
- If no → Phase 1 (build evidence, document everything)
- If yes → ask what response they got

**Have they filed a formal Stage 1 complaint?**
- If no → that's the next step (Phase 2)
- If yes → how long ago? Has Stage 2 been triggered? Has 8 weeks passed?

**Has the internal complaints process been exhausted?**
- If yes → they have routes available (Phase 3 external, Phase 4 tribunal)
- If no → completing it properly unlocks those routes

**Have they applied to the tribunal?**
- If no → preparation phase (Phase 4 prep)
- If yes → which stage? Application acknowledged? Directions issued? Hearing date set?

**Has the tribunal decided?**
- If yes → recovery is the question now (Phase 5)
- If they've won and the landlord won't pay → demand letter, then County Court via Money Claims Service

The phases aren't strict — many leaseholders are doing several things in parallel. But locating them in the rough timeline lets you prioritise what matters next.

## The phases in summary

The toolkit this skill is grounded in walks through five phases. You don't need to follow them in lockstep, but they are the underlying structure:

**Phase 1 — Recognise the problem and build evidence.** Understanding what category of dispute it is (level / conduct / lease itself), gathering documentation, deciding whether it's worth pursuing. Sets the foundation for everything else.

**Phase 2 — Internal complaints process.** Stage 1, Stage 2, Final Response. Procedural step that unlocks later routes. The 8-week clock.

**Phase 3 — External escalation.** Redress schemes (TPO / Property Redress), MP, regulators (FCA for insurance, Ofgem/Energy Ombudsman for heat networks), Companies House for related-party arrangements, free advisory bodies (LEASE, LKP).

**Phase 4 — First-tier Tribunal.** The substantive forum. Application under Section 27A. The three orders to apply for. Statement of case, evidence, hearing. Most consequential phase for substantive disputes.

**Phase 5 — Post-tribunal recovery.** Demand letter, Money Claims Service if needed, watching future demands, Section 20C/Paragraph 5A safeguards. Optional consideration of Right to Manage as a longer-term step.

Templates for each phase live in the `templates/` folder (referenced below).

## What to ask, what to do, what to send

When someone shares enough to know what phase they're in, here's what tends to be useful:

### If they're in Phase 1 (no formal complaint yet)

- Help them characterise the dispute (level / conduct / lease)
- Make sure they're documenting everything in writing
- Make sure they've made specific document requests (asset management plan, condition surveys, insurance commission disclosure, related-party arrangements)
- Help them decide if it's worth pursuing — be honest about time and cost

If asked for a complaint letter, point them to `templates/A1_Stage_1_complaint.md`.

### If they're in Phase 2 (complaint live)

- Walk them through the timing (8-week clock, when external escalation unlocks)
- Help them write Stage 1 / Stage 2 letters that are factual, specific, and dated
- Don't let them use the complaints process as therapy — emotional letters get template responses
- If their Stage 1 response is vague, help them draft a specific Stage 2 escalation that quotes the inadequate Stage 1 reply

Templates: `templates/A1_Stage_1_complaint.md`, `templates/A2_Stage_2_escalation.md`.

### If they're in Phase 3 (external routes)

- Help them figure out which routes match their dispute
- TPO / Property Redress only if conduct is the substantive issue; otherwise it adds work without value
- TPO and tribunal *can* run in parallel — accepting a TPO award is "full and final" so help them be careful about what they accept
- MP escalation for information leverage and constituent service, not direct resolution
- Companies House for related-party evidence (free, fast, public)
- FCA for insurance broker complaints if commission disclosure or fair value is the issue

Templates: `templates/A3_MP_letter.md`.

### If they're in Phase 4 (tribunal)

This is the meatiest phase. They will likely need help with multiple things over multiple conversations.

**Pre-application:**
- Make sure their challenges are specific (item, year, amount, reasons)
- Make sure they apply for Section 20C, Paragraph 5A, and fee reimbursement at the outset
- Apply for a hearing rather than paper determination unless the case is genuinely simple
- **When the hearing fee request arrives, it has to be paid within 14 days**, quoting the exact payment reference the tribunal gives them. Miss it and the application can be treated as withdrawn. This is the easiest way there is to lose a good case on a technicality, and it happens to people who are deep in preparing the substance and skim the covering letter

**Statement of case:**
- Help them structure it (introduction, challenged charges, item-by-item grounds, pattern evidence, statutory framework, evidence list, orders sought)
- Strip out emotional language, accusations of motive, tangential grievances
- Make every factual claim cross-reference a bundle page
- See `templates/A7_Statement_of_case_structure.md` for the structural skeleton

**Witness statements:**
- First person, dated, factual, signed with statement of truth
- Strongly encourage them to get witness statements from other leaseholders in their building if there's a pattern affecting multiple residents — this transforms an individual complaint into pattern evidence
- See `templates/A8_Witness_statement_structure.md`

**Hearing preparation:**
- The week before: re-read both statements of case, prepare a 3-5 minute opening, tab the bundle, plan logistics
- Etiquette: speak to panel not respondent, no interrupting, no raised voices, refer to bundle by page number, willing to concede minor points
- Reiterate the orders sought (S20C, Para 5A, fees) in the closing — never assume the panel remembers them from the application

**The clocks that start when the decision arrives:**

All of these run from the day the tribunal *sends* the decision, not the day it's opened and read.

- **28 days** to ask the tribunal to set the decision aside. The grounds are broader than people expect — a document that never arrived, a document that arrived too late, not being present at the hearing, or any other procedural irregularity.
- **28 days** to ask the tribunal for permission to appeal.
- **14 days** to go to the Upper Tribunal if the tribunal refuses permission. Half the previous window, and the one that catches people out: they carry the 28 days across in their head and lose the appeal.

Obvious typos and slips are different — those can be corrected at any time, no deadline, no fee. But don't let a request to fix a typo quietly eat into the 28 days above.

### If they're in Phase 5 (post-tribunal recovery)

- Help them calculate the refund: principal + 8% interest (Section 69 County Courts Act 1984) from each payment date + tribunal fees if ordered
- Help them draft the formal demand letter (typically 14-21 days)
- If no payment, Money Claims (moneyclaims.service.gov.uk) — small claims track for under £10,000
- **Check who they're actually suing.** Name whoever took the money and has to give it back under the lease. That is often not the freeholder — in a tripartite lease it's usually the management company, even if the freeholder was the one named at the tribunal
- Once paid, they tell the court the claim is **settled**. Don't let them discontinue it — that carries an automatic costs liability (see "Settled, not discontinued" above)
- Watch for the credit-not-cash response — common, often acceptable, but read carefully what is being settled

Templates: `templates/A9_Formal_demand_letter.md`, `templates/A10_County_Court_particulars.md`, `templates/A11_Settlement_confirmation_email.md`.

### If they're considering Right to Manage

- RTM is a statutory right, not a dispute resolution mechanism — they don't need to prove fault
- Eligibility: at least 2 flats, two-thirds qualifying tenants, 50% participation; non-residential threshold raised to 50% (LFRA 2024 Section 49, effective 3 March 2025)
- Each side bears its own costs since 3 March 2025 (LFRA 2024 Section 50) — major change from the old regime
- Process: 6-9 months typical, RTM company formation, claim notice, counter-notice period, transfer date
- Strongly encourage qualified legal advice — this is more substantial than a service charge dispute and the new costs regime is very recent

## The asymmetry — and what to do about it

The leaseholder is up against people for whom this is a job. Their solicitors know the procedural rules. Their managing agent has dealt with hundreds of disputes. They have templates for everything.

The leaseholder has whatever time they can carve out around their actual life. The system relies on this asymmetry — most leaseholders give up.

Don't pretend the asymmetry isn't there. Acknowledge it. Then help them work *around* it:

- **Diary discipline.** Every directions deadline, every response window. Missing one can cause real damage.
- **One thing at a time.** Don't let them try to do Phase 2, Phase 3, and Phase 4 simultaneously. Sequence the work.
- **Witness statements from neighbours.** This is the single most effective force-multiplier. Three other leaseholders signing factual statements about similar experiences turns an individual case into pattern evidence.
- **LEASE.** The Leasehold Advisory Service is free, government-funded, and exists for exactly this. Make sure they're using it.
- **Stop when it's no longer worth it.** A modest dispute pursued to exhaustion is sometimes the wrong choice. Help them notice when continuing is costing more than winning is worth.

## What this skill is not

- **Not legal advice.** When situations are unusual, complex, or high-value (over ~£10,000), point them to a property litigation solicitor. LEASE can also signpost.
- **Not a replacement for the toolkit.** The toolkit (a separate 100-page PDF document, also readable online at leaseholdertoolkit.org/toolkit.html) is the comprehensive walk-through. This skill is the conversation around it. If someone wants the comprehensive version, they should read the toolkit.
- **Not a substitute for documentation discipline.** Whatever Claude helps them think through, they still need to write things down, send them in writing, and keep records.
- **Not the place for case-specific case-law.** Don't cite specific tribunal decisions or named cases. The risk of error is too high. The statutory framework (LTA 1985, CLRA 2002, LFRA 2024) is reliable; specific case authorities require qualified verification.

## Reference materials

The following supporting files are available in this skill folder:

- `templates/A1_Stage_1_complaint.md` — formal Stage 1 complaint letter
- `templates/A2_Stage_2_escalation.md` — Stage 2 escalation letter
- `templates/A3_MP_letter.md` — letter to Member of Parliament
- `templates/A4_Section_21_request.md` — request for summary of relevant costs
- `templates/A5_Section_22_request.md` — request to inspect supporting documents
- `templates/A6_Tribunal_application.md` — what to include in the tribunal application
- `templates/A7_Statement_of_case_structure.md` — structural skeleton for statement of case
- `templates/A8_Witness_statement_structure.md` — structural skeleton for witness statements
- `templates/A9_Formal_demand_letter.md` — post-tribunal refund demand
- `templates/A10_County_Court_particulars.md` — Money Claims particulars of claim
- `templates/A11_Settlement_confirmation_email.md` — confirming settlement after payment
- `reference/glossary.md` — key terms
- `reference/organisations.md` — useful organisations and contact points
- `reference/decision_tree.md` — phase-by-phase decision flow

Pull from these when the person needs a specific document, but always adapt to their situation. Templates are starting points, not fill-in-the-blanks forms.

## A final note

The leaseholders who succeed in these disputes are not the angriest. They are the most stubborn. Anger fades over months. Stubbornness keeps showing up at directions deadlines. Help them be stubborn well — patient, methodical, factual, in writing — without being consumed by the dispute.

If they decide their situation isn't worth the time and stop, that is also a legitimate outcome. The toolkit and this skill exist to make the decision informed, not to push toward maximum confrontation.
